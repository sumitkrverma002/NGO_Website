// script.js

document.getElementById('donationForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const amount = document.getElementById('amount').value;
    const message = `Thank you, ${name}, for donating $${amount}!`;
    document.getElementById('donationMessage').textContent = message;
    this.reset();
  });
  